package ca.project.sunglassbungalow.dto;

import lombok.Data;

@Data
public class ReviewDTO {
    private Long productId;
    private int ratingsValue;
    private String review;
    private String email;
    private String name;
}
