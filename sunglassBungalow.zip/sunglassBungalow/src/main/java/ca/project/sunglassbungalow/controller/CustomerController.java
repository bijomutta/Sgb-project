package ca.project.sunglassbungalow.controller;

import ca.project.sunglassbungalow.dto.CustomerInfoDTO;
import ca.project.sunglassbungalow.dto.CustomerPasswordDTO;
import ca.project.sunglassbungalow.exception.HttpResponse;
import ca.project.sunglassbungalow.exception.PasswordNotMatchException;
import ca.project.sunglassbungalow.exception.UserNotFoundException;
import ca.project.sunglassbungalow.service.OrderService;
import ca.project.sunglassbungalow.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import static ca.project.sunglassbungalow.utils.constants.Constants.API_PREFIX;

@RestController
@RequestMapping(API_PREFIX+"customer")
public class CustomerController {

    @Autowired
    private OrderService orderService;
    @Autowired
    private UserService userService;


    @PostMapping("update-info")
    public ResponseEntity<?> updateInfo(@RequestBody CustomerInfoDTO customerInfoDTO) throws UserNotFoundException {
        if(customerInfoDTO!=null)
        {
            return new ResponseEntity<>(userService.updateCustomerInfo(customerInfoDTO), HttpStatus.OK);
        }
        else
        {
            return response(HttpStatus.BAD_REQUEST,"Empty Body");
        }
    }

    @PostMapping("update-password")
    public ResponseEntity<?> updatePassword(@RequestBody CustomerPasswordDTO customerPasswordDTO) throws UserNotFoundException, PasswordNotMatchException {
        if(customerPasswordDTO!=null)
        {
            return new ResponseEntity<>(userService.updateCustomerPassword(customerPasswordDTO), HttpStatus.OK);
        }
        else
        {
            return response(HttpStatus.BAD_REQUEST,"Empty Body");
        }
    }

    @GetMapping("orders/{email}")
    public ResponseEntity<?> getByCustomerEmail(@PathVariable String email)
    {
        if(email!=null && orderService.findByCustomerEmail(email)!=null)
        {
            return new ResponseEntity<>(orderService.findByCustomerEmail(email),HttpStatus.OK);
        }
        else
        {
            return response(HttpStatus.BAD_REQUEST,"this Email  does not Exist Or It Does not Have any Orders");
        }
    }

    private ResponseEntity<HttpResponse> response(HttpStatus httpStatus, String message) {
        return new ResponseEntity<>(new HttpResponse(httpStatus.value(), httpStatus, httpStatus.getReasonPhrase().toUpperCase(),
                message), httpStatus);
    }

}
