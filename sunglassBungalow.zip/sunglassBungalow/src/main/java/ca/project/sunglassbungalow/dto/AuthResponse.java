package ca.project.sunglassbungalow.dto;

import ca.project.sunglassbungalow.entity.User;
import lombok.Data;

@Data
public class AuthResponse {
    private String token;
    private User user;
}
