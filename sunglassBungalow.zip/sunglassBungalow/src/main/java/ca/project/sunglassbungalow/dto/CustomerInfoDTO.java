package ca.project.sunglassbungalow.dto;

import lombok.Data;

@Data
public class CustomerInfoDTO {
    private String firstName;
    private String lastName;
    private String email;
}
