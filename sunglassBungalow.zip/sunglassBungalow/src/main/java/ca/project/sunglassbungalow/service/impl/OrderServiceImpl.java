package ca.project.sunglassbungalow.service.impl;

import ca.project.sunglassbungalow.dao.OrderRepository;
import ca.project.sunglassbungalow.entity.Order;
import ca.project.sunglassbungalow.exception.OrderNotFoundException;
import ca.project.sunglassbungalow.service.OrderService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderRepository orderRepository;


    @Override
    public List<Order> findByCustomerEmail(String email)
    {
        return orderRepository.findAllByCustomer_Email(email);
    }
    @Override
    public List<Order> findAll()
    {
        log.info("******** getting All orders List ***********");
        if(orderRepository.findAll().isEmpty())
        {
            log.warn("******* orders list is empty **********");
            return new ArrayList<>();
        }
        else
        {
            return orderRepository.findAll();
        }
    }

    @Override
    public Order updateStatus(Long orderId,String status) throws OrderNotFoundException {
        log.info("********* retreiving order with ID: {} *************",orderId);
        Order order=findById(orderId);
        return order;
    }

    @Override
    public Order findById(Long orderId) throws OrderNotFoundException {
        log.info("******** finding Order By ID:{} **************",orderId);
        if(orderRepository.findById(orderId).isPresent())
        {
            log.info("********* order Found with ID{}-*********",orderId);
            return orderRepository.findById(orderId).get();
        }
        else
        {
            log.warn("******** Order Not FOUND with ID:{} ***********",orderId);
            throw new OrderNotFoundException("Order Not Found");
        }
    }

    @Override
    public void delete(Long orderid)
    {
        log.info("deleting order with ID:{}",orderid);
        orderRepository.deleteById(orderid);
        log.info("order deleted ");
    }

}
