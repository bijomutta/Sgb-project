package ca.project.sunglassbungalow.service;

import ca.project.sunglassbungalow.dto.CustomerInfoDTO;
import ca.project.sunglassbungalow.dto.CustomerPasswordDTO;
import ca.project.sunglassbungalow.dto.UserDTO;
import ca.project.sunglassbungalow.entity.User;
import ca.project.sunglassbungalow.exception.EmailExistException;
import ca.project.sunglassbungalow.exception.EmailNotFoundException;
import ca.project.sunglassbungalow.exception.PasswordNotMatchException;
import ca.project.sunglassbungalow.exception.UserNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * The interface User service.
 */
@Service
public interface UserService {
    User updateCustomerInfo(CustomerInfoDTO customerInfoDTO) throws UserNotFoundException;

    User updateCustomerPassword(CustomerPasswordDTO customerPasswordDTO) throws UserNotFoundException, PasswordNotMatchException;

    /**
     * Find all list.
     *
     * @return the list
     */


    List<User> findAllCustomer();

    List<User> findAllAdmins();

    /**
     * Find by id user.
     *
     * @param id the id
     * @return the user
     * @throws UserNotFoundException the user not found exception
     */
    User findById(Long id) throws UserNotFoundException;

    /**
     * Register user.
     *
     * @param userDTO the user dto
     * @return the user
     * @throws EmailExistException the email exist exception
     */
    User register(UserDTO userDTO) throws EmailExistException, UserNotFoundException;

    /**
     * Create user user.
     *
     * @param userDTO the user dto
     * @return the user
     * @throws EmailExistException the email exist exception
     */
    User createUser(UserDTO userDTO) throws EmailExistException, UserNotFoundException;

    /**
     * Update user user.
     *
     * @param userId  the user id
     * @param userDTO the user dto
     * @return the user
     * @throws EmailNotFoundException the email not found exception
     */
    User updateUser(Long userId, UserDTO userDTO) throws EmailNotFoundException, UserNotFoundException;

    /**
     * Find user by email user.
     *
     * @param email the email
     * @return the user
     */
    User findUserByEmail(String email) throws UserNotFoundException;

    /**
     * Delete.
     *
     * @param id the id
     */
    void delete(Long id);
}
