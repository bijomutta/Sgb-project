package ca.project.sunglassbungalow.service.impl;

import ca.project.sunglassbungalow.dao.OrderRepository;
import ca.project.sunglassbungalow.dao.UserRepository;
import ca.project.sunglassbungalow.dto.Purchase;
import ca.project.sunglassbungalow.dto.PurchaseResponse;
import ca.project.sunglassbungalow.entity.Order;
import ca.project.sunglassbungalow.entity.OrderItem;
import ca.project.sunglassbungalow.entity.User;
import ca.project.sunglassbungalow.service.CheckoutService;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Set;
import java.util.UUID;

@Service
@Slf4j
public class CheckoutServiceImpl implements CheckoutService {

    @Autowired
    private UserRepository customerRepository;

    @Autowired
    private OrderRepository orderRepository;

    private static final String[] ROLE_CUSTOMER = {"ROLE_CUSTOMER"};


    @Override
    @Transactional
    public PurchaseResponse placeOrder(Purchase purchase) {

        log.info("***** retreiving the order info from DTO *********");
        //retreive the order infos from dto
        Order order = purchase.getOrder();

        log.info("***** generate tracking number *********");
        //generate tracking number
        String orderTrackingNumber = generateOrderTrackingNumber();
        order.setOrderTrackingNumber(orderTrackingNumber);

        log.info("***** populate order with orderItems *********");
        //populate order with orderItems
        Set<OrderItem> orderItems = purchase.getOrderItems();
        orderItems.forEach(item -> order.add(item));

        log.info("***** populate order with billingAddress and shipping Address *********");
        //populate order with billingAddress and shipping Address
        order.setBillingAddress(purchase.getBillingAddress());
        order.setShippingAddress(purchase.getShippingAddress());

        log.info("***** populate customer with order *********");
        //populate customer with order
        User customer = purchase.getCustomer();

        log.info("***** check if this is an existing customer {} *********", customer.getEmail());
        //check if this is an existing customer
        String theEmail = customer.getEmail();


        User customerFromDB = customerRepository.findUserByEmail(theEmail).orElse(null);

        if (customerFromDB != null) {
            log.info("***** this customer Aleady Exist {} *********", customer.getEmail());
            customerFromDB.setPhone(purchase.getCustomer().getPhone());
            customer = customerFromDB;

        }

        //adding shipping and billing address to the customer infos

           customer.setShippingAddress(purchase.getShippingAddress());
           customer.setBillingAddress(purchase.getBillingAddress());
           customer.setRoles(ROLE_CUSTOMER);

        order.setCustomer(customerRepository.save(customer));
        orderRepository.save(order);

        return new PurchaseResponse(orderTrackingNumber);


    }

    private String generateOrderTrackingNumber() {
        return UUID.randomUUID().toString();
    }

}
