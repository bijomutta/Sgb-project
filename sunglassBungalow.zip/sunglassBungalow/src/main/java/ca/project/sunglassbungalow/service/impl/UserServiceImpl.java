package ca.project.sunglassbungalow.service.impl;

import ca.project.sunglassbungalow.dao.UserRepository;
import ca.project.sunglassbungalow.dto.CustomerInfoDTO;
import ca.project.sunglassbungalow.dto.CustomerPasswordDTO;
import ca.project.sunglassbungalow.dto.UserDTO;
import ca.project.sunglassbungalow.entity.User;
import ca.project.sunglassbungalow.entity.UserPrincipal;
import ca.project.sunglassbungalow.exception.EmailExistException;
import ca.project.sunglassbungalow.exception.EmailNotFoundException;
import ca.project.sunglassbungalow.exception.PasswordNotMatchException;
import ca.project.sunglassbungalow.exception.UserNotFoundException;
import ca.project.sunglassbungalow.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import static ca.project.sunglassbungalow.utils.constants.UserImplConstant.*;

@Service
@Slf4j
@Qualifier("userDetailsService")
public class UserServiceImpl implements UserService, UserDetailsService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    private static final String[] ROLE_ADMIN = {"ROLE_ADMIN"};
    private static final String[] ROLE_CUSTOMER = {"ROLE_CUSTOMER"};


    @Override
    public  User updateCustomerInfo(CustomerInfoDTO customerInfoDTO) throws UserNotFoundException {
        if(userRepository.findUserByEmail(customerInfoDTO.getEmail()).isPresent())
        {
            User user=userRepository.findUserByEmail(customerInfoDTO.getEmail()).get();
            user.setFirstName(customerInfoDTO.getFirstName());
            user.setLastName(customerInfoDTO.getLastName());
            user.setEmail(customerInfoDTO.getEmail());
            userRepository.save(user);
            return user;
        }
        else
        {
            log.error("********* User Does Not Exist with Email: {} ************", customerInfoDTO.getEmail());
            throw new UserNotFoundException("User NOT FOUND");
        }

    }
    @Override
    public  User updateCustomerPassword(CustomerPasswordDTO customerPasswordDTO) throws UserNotFoundException, PasswordNotMatchException {
        if(userRepository.findUserByEmail(customerPasswordDTO.getEmail()).isPresent())
        {

            User user=userRepository.findUserByEmail(customerPasswordDTO.getEmail()).get();
            boolean isMatch=passwordEncoder.matches(customerPasswordDTO.getCurrentPassword(), user.getPassword());
            if(isMatch)
            {
                user.setPassword(encodePassword(customerPasswordDTO.getPassword()));
                userRepository.save(user);
                return user;
            }
            else
            {
                log.error("Password Does Not Match");
                throw new PasswordNotMatchException("Password Does Not Match");
            }

        }
        else
        {
            log.error("********* User Does Not Exist with Email: {} ************", customerPasswordDTO.getEmail());
            throw new UserNotFoundException("User NOT FOUND");
        }

    }
    @Override
    public List<User> findAllCustomer() {
        log.info("******* getting all customers list *********");
        return userRepository.findAll().stream().filter(user -> user.getRoles()[0].equals("ROLE_CUSTOMER")).collect(Collectors.toList());
    }
    @Override
    public List<User> findAllAdmins() {
        log.info("******* getting all admins list *********");
        return userRepository.findAll().stream().filter(user -> user.getRoles()[0].equals("ROLE_ADMIN")).collect(Collectors.toList());

    }


    @Override
    public User findById(Long id) throws UserNotFoundException {
        log.info("****** getting user By ID : {} ***********", id);
        User user = userRepository.findById(id).get();
        if (user != null) {
            return user;
        } else {
            log.error("********* User Does Not Exist with ID: {} ************", id);
            throw new UserNotFoundException("User NOT FOUND");

        }
    }


    @Override
    public User register(UserDTO userDTO) throws EmailExistException, UserNotFoundException {
        log.info("******** new customer register *********");
        return getUser(userDTO, ROLE_CUSTOMER);
    }


    @Override
    public User createUser(UserDTO userDTO) throws EmailExistException, UserNotFoundException {
        log.info("******** new Admin creation *********");
        return getUser(userDTO, ROLE_ADMIN);
    }

    private User getUser(UserDTO userDTO, String[] roles) throws EmailExistException, UserNotFoundException {

        if (!validateEmail(userDTO.getEmail())) {
            log.info("******* creating new user **********");
            User user = User.builder()
                    .firstName(userDTO.getFirstName())
                    .lastName(userDTO.getLastName())
                    .email(userDTO.getEmail())
                    .password(encodePassword(userDTO.getPassword()))
                    .roles(roles)
                    .isAccountExpired(false)
                    .isEnabled(true)
                    .isAccountNonLocked(true)
                    .build();

            userRepository.save(user);
            log.info("********* user saved to database **********");
            return user;

        } else {
            log.warn("********** Email Already Exist {} ************", userDTO.getEmail());
            throw new EmailExistException(EMAIL_ALREADY_EXISTS + userDTO.getEmail());
        }
    }

    @Override
    public User updateUser(Long userId, UserDTO userDTO) throws EmailNotFoundException, UserNotFoundException {
        if (userRepository.findById(userId).isPresent()) {
            log.info("********** updating user with ID {} *************", userId);
            User user = userRepository.findById(userId).get();
            user.setEmail(userDTO.getEmail());
            user.setFirstName(userDTO.getFirstName());
            user.setLastName(userDTO.getLastName());
            user.setPassword(encodePassword(user.getPassword()));

            userRepository.save(user);
            log.info("**********  user with ID {} is updated *************", userId);
            return user;
        } else {
            log.error("********** user not Found with ID {} *************", userId);
            throw new UserNotFoundException("No User Found With ID "+userId );
        }

    }


    private Boolean validateEmail(String newEmail) throws UserNotFoundException {


        User user = findUserByEmail(newEmail);
        if (user != null) {
            log.info("**********  user with email {} FOUND  *************", newEmail);
            return true;
        } else {
            log.info("**********  user with email {} NOT FOUND  *************", newEmail);
            return false;
        }
    }


    @Override
    public User findUserByEmail(String email) throws UserNotFoundException {
        log.info("**********  finding user by  email {} *************", email);
        if(userRepository.findUserByEmail(email).isPresent())
        {
            log.info("User Found");
            return userRepository.findUserByEmail(email).get();
        }
        else
        {
            log.error("user Not FOUND");
           return null;
        }

    }

    @Override
    public void delete(Long id) {
        log.info("******* deleting user with ID: {} ********", id);
        userRepository.deleteById(id);
        log.info("******* DELETED user with ID: {}*********", id);
    }

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        User user = null;
        try {
            user = findUserByEmail(email);
        } catch (UserNotFoundException e) {
            throw new RuntimeException(e);
        }
        if (user == null) {
            log.error("******** user NOT FOUND with email:{}*********", email);
            throw new UsernameNotFoundException(NO_USER_FOUND_BY_USERNAME + email);
        } else {
            log.info("******** user  FOUND with email:{}*********", email);
            user.setLastLoginDateDisplay(user.getLastLoginDate());
            user.setLastLoginDate(new Date());
            userRepository.save(user);
            UserPrincipal userPrincipal = new UserPrincipal(user);
            return userPrincipal;
        }
    }


    private String encodePassword(String password) {
        return passwordEncoder.encode(password);
    }
}
