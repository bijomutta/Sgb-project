package ca.project.sunglassbungalow.service.impl;

import ca.project.sunglassbungalow.dao.ProductCategoryRepository;
import ca.project.sunglassbungalow.dao.ProductRepository;
import ca.project.sunglassbungalow.dao.ReviewRepository;
import ca.project.sunglassbungalow.dto.ProductDTO;
import ca.project.sunglassbungalow.dto.ReviewDTO;
import ca.project.sunglassbungalow.entity.Product;
import ca.project.sunglassbungalow.entity.ProductCategory;
import ca.project.sunglassbungalow.entity.Review;
import ca.project.sunglassbungalow.exception.CategoryNotFoundException;
import ca.project.sunglassbungalow.service.ProductService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * The type Product service.
 */
@Service
@Slf4j
public class ProductServiceImpl implements ProductService {


    @Autowired
    private ProductRepository productRepository;
    @Autowired
    private ProductCategoryRepository productCategoryRepository;
    @Autowired
    private ReviewRepository reviewRepository;

    @Override
    public List<Product> sortByName(String name, String dir) {
        log.info("***** sorting products list by name : {} and direction {} *********", name, dir);
        List<Product> products = productRepository.findAll(Sort.by(createSortOrder(name, dir)));
        if(products.isEmpty())
        {
            log.warn("****** products list is empty *******");
            return new ArrayList<>();
        }
        else
        {
            return products;
        }
    }

    @Override
    public List<Product> sortByPrice(String price, String dir) {
        log.info("***** sorting products list by price : {} and direction {} *********", price, dir);
        List<Product> products = productRepository.findAll(Sort.by(createSortOrder(price, dir)));
        if(products.isEmpty())
        {
            log.warn("****** products list is empty *******");
            return new ArrayList<>();
        }
        else
        {
            return products;
        }
    }

    @Override
    public List<Product> filterByBrand(String[] brands) {
        log.info("***** filtering products list by brand : {} *********", brands);
        List<Product> products=productRepository.findAll();
        List<Product> filteredProducts = products.stream()
                .filter(product -> Arrays.stream(brands).anyMatch(brand -> brand.equals(product.getBrand())))
                .collect(Collectors.toList());
        return filteredProducts;

    }


    @Override
    public List<Product> filterByName(String name) {
        log.info("***** filtering products list by name : {}  *********", name);
        return productRepository.findAllByNameContainingIgnoreCase(name);
    }

    @Override
    public List<Product> filterByColor(List<String> color)
    {
        List<Product> products=productRepository.findAll();
        List<Product> filteredProducts = products.stream()
                .filter(product -> Arrays.stream(product.getColor()).anyMatch(color::contains))
                .collect(Collectors.toList());


        log.info("***** filtering products list by color : {}  *********", color);
        return filteredProducts;
    }

    @Override
    public List<Product> filterByCategory(String category) {
        log.info("***** filtering products list by category : {}  *********", category);
        return productRepository.findAllByCategory_Name(category);
    }


    @Override
    public List<Product> findAll() {
        log.info("***** retreiving  products list   *********");
        return productRepository.findAll();
    }

    @Override
    public Product findById(Long productId) {
        log.info("***** finding product  by ID : {}  *********", productId);
        if(productRepository.findById(productId).isPresent())
        {
            log.info("*****  product FOUND   *********");
            return productRepository.findById(productId).get();
        }
        else
        {
            log.error("*****  product NOT FOUND   *********");
            return null;
        }
    }

    @Override
    public Product addProduct(ProductDTO productDTO) throws CategoryNotFoundException {
        log.info("***** creating new product  with  name : {}  *********", productDTO.getName());
        log.info("***** finding category  with  ID : {}  *********", productDTO.getCategoryId());

        if(productCategoryRepository.findById(productDTO.getCategoryId()).isPresent())
        {
            log.info("*****  product FOUND   *********");
            ProductCategory productCategory= productCategoryRepository.findById(productDTO.getCategoryId()).get();

            log.info("***** adding the category  with  name : {}  *********", productCategory.getName());
            Product product = new Product();
            product.setName(productDTO.getName());
            product.setBrand(productDTO.getBrand());
            product.setCategory(productCategory);
            product.setDescription(productDTO.getDescription());
            product.setOldPrice(productDTO.getOldPrice());
            product.setNewPrice(productDTO.getNewPrice());
            product.setAvailibilityCount(productDTO.getAvailibilityCount());
            product.setColor(productDTO.getColor());
            product.setDiscount(productDTO.getDiscount());
            product.setImage(productDTO.getImage());
            productRepository.save(product);
            log.info("***** product saved to database  *********");

            return product;
        }
        else
        {
            log.error("*****  Category NOT FOUND   *********");
            throw new CategoryNotFoundException("Category NOT FOUND");
        }

    }

    @Override
    public Product updateProduct(Long productId, ProductDTO productDTO) {
        log.info("***** updating product  with  name : {}  *********", productDTO.getName());
        log.info("***** finding category  with  ID : {}  *********", productDTO.getCategoryId());
        ProductCategory productCategory = productCategoryRepository.findById(productDTO.getCategoryId()).get();
        log.info("***** adding the category  with  name : {}  *********", productCategory.getName());

        Product product = productRepository.findById(productId).get();
        product.setName(productDTO.getName());
        product.setDescription(productDTO.getDescription());
        product.setAvailibilityCount(productDTO.getAvailibilityCount());
        product.setOldPrice(productDTO.getOldPrice());
        product.setNewPrice(productDTO.getNewPrice());
        product.setBrand(productDTO.getBrand());
        product.setColor(product.getColor());
        product.setImage(productDTO.getImage());
        product.setDiscount(productDTO.getDiscount());
        product.setCategory(productCategory);

        productRepository.save(product);
        log.info("***** product updated  *********");
        return product;
    }

    @Override
    public Product addReview(Long productId, ReviewDTO reviewDTO)
    {
        Product product = productRepository.findById(productId).get();

        Review review=new Review();
        review.setEmail(reviewDTO.getEmail());
        review.setFullName(reviewDTO.getName());
        review.setMessage(reviewDTO.getReview());
        review.setRating(reviewDTO.getRatingsValue());


        if(product.getReviewId()!=null)
        {
            Long[] newArr = new Long[product.getReviewId().length + 1];
            System.arraycopy(product.getReviewId(), 0, newArr, 0, product.getReviewId().length);
            newArr[newArr.length - 1] = reviewRepository.save(review).getId();
            product.setReviewId(newArr);
        }
        else
        {
            Long[] newArr = new Long[1];
            newArr[newArr.length - 1] = reviewRepository.save(review).getId();
            product.setReviewId(newArr);
        }


        product.setRatingsCount(product.getRatingsCount()+ 1);
        product.setRatingsValue(product.getRatingsValue()+ reviewDTO.getRatingsValue());
        productRepository.save(product);
        return product;
    }

    @Override
    public  List<Review> getReviews(Long id)
    {
        Product product = productRepository.findById(id).get();

        List<Review> reviews=new ArrayList<>();
        for(Long aLong:product.getReviewId())
        {
            Review review=reviewRepository.findById(aLong).get();
            reviews.add(review);
        }
        return reviews;
    }

    @Override
    public void deleteProduct(Long productId) {
        log.info("***** deleting product with ID : {}  *********", productId);
        productRepository.deleteById(productId);
        log.info("*****  product with ID : {} DELETED *********", productId);
    }


    private List<Sort.Order> createSortOrder(String sortName, String sortDirection) {
        List<Sort.Order> sorts = new ArrayList<>();
        Sort.Direction direction;

        if (sortDirection .equals("asc") ) {
            direction = Sort.Direction.ASC;
        } else if (sortDirection .equals("desc")){
            direction = Sort.Direction.DESC;
        }
        else
        {
            direction = Sort.Direction.DESC;
        }
        sorts.add(new Sort.Order(direction, sortName));

        return sorts;
    }
}
