package ca.project.sunglassbungalow.dto;

import lombok.Data;

@Data
public class CustomerPasswordDTO {
    private String email;
    private String currentPassword;
    private String password;
}
