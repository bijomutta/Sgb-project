package ca.project.sunglassbungalow.controller;

import ca.project.sunglassbungalow.dto.ProductDTO;
import ca.project.sunglassbungalow.dto.ReviewDTO;
import ca.project.sunglassbungalow.entity.Product;
import ca.project.sunglassbungalow.exception.CategoryNotFoundException;
import ca.project.sunglassbungalow.exception.HttpResponse;
import ca.project.sunglassbungalow.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import static ca.project.sunglassbungalow.utils.constants.Constants.API_PREFIX;

/**
 * The type Product controller.
 */
@RestController
@RequestMapping(API_PREFIX+"product")
public class ProductController {

    @Autowired
    private ProductService productService;


    /**
     * Sort by name response entity.
     *
     * @param name the name
     * @param dir  the dir
     * @return the response entity
     */
    @GetMapping("sort-name")
    public ResponseEntity<?> sortByName(@RequestParam("name")String name,
                                                    @RequestParam("dir")String dir)
    {
        if(name!=null && dir.equals("asc") || dir.equals("desc"))
        {
            return new ResponseEntity<>(productService.sortByName(name,dir),HttpStatus.OK);
        }
        else
        {
            return  response(HttpStatus.BAD_REQUEST,"please provide correct direction (asc or desc)");
        }
    }

    /**
     * Sort by price response entity.
     *
     * @param price the price
     * @param dir   the dir
     * @return the response entity
     */
    @GetMapping("sort-price")
    public ResponseEntity<?> sortByPrice(@RequestParam("name")String price,
                                                    @RequestParam("dir")String dir)
    {
        if(price!=null  && dir.equals("asc") || dir.equals("desc"))
        {
            return new ResponseEntity<>(productService.sortByPrice(price,dir),HttpStatus.OK);
        }
        else
        {
            return  response(HttpStatus.BAD_REQUEST,"please provide correct direction (asc or desc)");
        }
    }

    /**
     * Filter by name response entity.
     *
     * @param name the name
     * @return the response entity
     */
    @GetMapping("filter-name")
    public ResponseEntity<?> filterByName(@RequestParam("name")String name)
    {
        if(name !=null)
        {
            return new ResponseEntity<>(productService.filterByName(name),HttpStatus.OK);
        }
        else
        {
            return response(HttpStatus.BAD_REQUEST,"please provide a Name");
        }
    }

    @PostMapping("filter-color")
    public ResponseEntity<?> filterByColor(@RequestBody String[] color)
    {
        if(color !=null)
        {
            return new ResponseEntity<>(productService.filterByColor(Arrays.asList(color)),HttpStatus.OK);
        }
        else
        {
            return response(HttpStatus.BAD_REQUEST,"please provide a Name");
        }
    }

    /**
     * Filter by brand response entity.
     *
     * @param brands the brand
     * @return the response entity
     */
    @PostMapping("filter-brand")
    public ResponseEntity<?> filterByBrand(@RequestBody String[] brands)
    {
        if(brands!=null)
        {
            return new ResponseEntity<>(productService.filterByBrand(brands),HttpStatus.OK);
        }
        else
        {
            return response(HttpStatus.BAD_REQUEST,"please provide a Brand Name");
        }

    }

    /**
     * Filter by category response entity.
     *
     * @param category the category
     * @return the response entity
     */
    @GetMapping("filter-category")
    public ResponseEntity<?> filterByCategory(@RequestParam("name")String category)
    {
        if(category!=null)
        {
            return new ResponseEntity<>(productService.filterByCategory(category),HttpStatus.OK);

        }
        else
        {
            return response(HttpStatus.BAD_REQUEST,"please provide Category Name");
        }
    }

    /**
     * Find by id response entity.
     *
     * @param id the id
     * @return the response entity
     */
    @GetMapping("find/{id}")
    public ResponseEntity<?> findById(@PathVariable Long id)
    {

        if(id!=null && productService.findById(id)!=null)
        {
            return new ResponseEntity<>(productService.findById(id), HttpStatus.OK);
        }
        else
        {
            return response(HttpStatus.BAD_REQUEST,"this product ID does not Exist");
        }

    }

    @GetMapping("reviews/{id}")
    public ResponseEntity<?> getReviews(@PathVariable Long id)
    {
        if(id!=null  && productService.findById(id)!=null)
        {
            return new ResponseEntity<>(productService.getReviews(id),HttpStatus.OK);
        }
        else
        {
            return   response(HttpStatus.BAD_REQUEST,"this product ID does not Exist");
        }

    }
    @PostMapping("add-review")
    public ResponseEntity<?> addReview(@RequestBody ReviewDTO reviewDTO)
    {
        if(reviewDTO.getProductId()!=null  && productService.findById(reviewDTO.getProductId())!=null)
        {
            return new ResponseEntity<>(productService.addReview(reviewDTO.getProductId(),reviewDTO),HttpStatus.OK);
        }
        else
        {
            return   response(HttpStatus.BAD_REQUEST,"this product ID does not Exist");
        }

    }
    /**
     * Find all response entity.
     *
     * @return the response entity
     */
    @GetMapping("all")
    public ResponseEntity<List<Product>> findAll()
    {
        return new ResponseEntity<>(productService.findAll(), HttpStatus.OK);
    }

    /**
     * Create response entity.
     *
     * @param product the product
     * @return the response entity
     * @throws IOException the io exception
     */
    @PostMapping("add")
    public ResponseEntity<Product> create(@RequestBody ProductDTO product) throws CategoryNotFoundException {
        return new ResponseEntity<>(productService.addProduct(product),HttpStatus.OK);
    }

    /**
     * Update response entity.
     *
     * @param product the product
     * @param id      the id
     * @return the response entity
     */
    @PutMapping("update/{id}")
    public ResponseEntity<?> update(@RequestBody ProductDTO product,
                                          @PathVariable Long id)
    {
        if(id!=null  && productService.findById(id)!=null)
        {
            return new ResponseEntity<>(productService.updateProduct(id,product),HttpStatus.OK);
        }
        else
        {
            return   response(HttpStatus.BAD_REQUEST,"this product ID does not Exist");
        }
    }

    /**
     * Delete response entity.
     *
     * @param id the id
     * @return the response entity
     */
    @DeleteMapping("delete/{id}")
    public ResponseEntity<HttpResponse> delete(@PathVariable Long id)
    {
        if(id!=null && productService.findById(id)!=null)
        {
            productService.deleteProduct(id);
         return   response(HttpStatus.OK,"product deleted Successfully");
        }
        else
        {
          return   response(HttpStatus.BAD_REQUEST,"this product ID does not Exist");
        }

    }

    private ResponseEntity<HttpResponse> response(HttpStatus httpStatus, String message) {
        return new ResponseEntity<>(new HttpResponse(httpStatus.value(), httpStatus, httpStatus.getReasonPhrase().toUpperCase(),
                message), httpStatus);
    }
}
