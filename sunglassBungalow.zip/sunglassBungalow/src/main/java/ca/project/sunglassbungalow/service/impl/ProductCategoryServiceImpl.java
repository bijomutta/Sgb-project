package ca.project.sunglassbungalow.service.impl;

import ca.project.sunglassbungalow.dao.ProductCategoryRepository;
import ca.project.sunglassbungalow.dto.CategoryDTO;
import ca.project.sunglassbungalow.entity.ProductCategory;
import ca.project.sunglassbungalow.service.ProductCategoryService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
public class ProductCategoryServiceImpl implements ProductCategoryService {

    @Autowired
    private ProductCategoryRepository productCategoryRepository;

    @Override
    public ProductCategory findById(Long categoryId) {
        log.info("***** finding category By ID : {} *********", categoryId);
        ProductCategory productCategory = productCategoryRepository.findById(categoryId).get();
        if (productCategory != null) {
            log.info("***** category FOUND with ID {} *********", categoryId);
            return productCategory;
        } else {
            log.warn("***** Category Not FOUND with ID: {} *********", categoryId);
            return null;

        }
    }

    @Override
    public List<ProductCategory> findAll() {
        log.info("***** retreiving all categories list *********");
        return productCategoryRepository.findAll();
    }

    @Override
    public ProductCategory addCategory(CategoryDTO categoryDTO) {

        log.info("***** adding new category with name : {} *********", categoryDTO.getName());
        ProductCategory productCategory = ProductCategory.builder()
                .name(categoryDTO.getName())
                .description(categoryDTO.getDescription())
                .build();
        productCategoryRepository.save(productCategory);
        log.info("*****  category with name : {} saved to database *********", categoryDTO.getName());
        return productCategory;
    }

    @Override
    public ProductCategory updateCategory(Long categoryId, CategoryDTO categoryDTO) {
        log.info("***** updating  category with name : {} *********", categoryDTO.getName());
        ProductCategory productCategory = productCategoryRepository.findById(categoryId).get();
        productCategory.setName(categoryDTO.getName());
        productCategory.setDescription(categoryDTO.getDescription());

        productCategoryRepository.save(productCategory);
        log.info("*****  category with name : {} UPDATED *********", categoryDTO.getName());
        return productCategory;
    }

    @Override
    public void deleteCategory(Long categoryId) {
        log.info("***** Deleting  category with ID : {} *********", categoryId);
        productCategoryRepository.deleteById(categoryId);
    }

}
