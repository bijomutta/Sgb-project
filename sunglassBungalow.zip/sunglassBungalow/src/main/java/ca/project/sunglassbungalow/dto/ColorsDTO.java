package ca.project.sunglassbungalow.dto;

import lombok.Data;

@Data
public class ColorsDTO {
    private String[] colors;
}
