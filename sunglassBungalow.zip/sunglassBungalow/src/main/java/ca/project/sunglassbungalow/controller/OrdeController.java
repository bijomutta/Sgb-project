package ca.project.sunglassbungalow.controller;

import ca.project.sunglassbungalow.entity.Order;
import ca.project.sunglassbungalow.exception.HttpResponse;
import ca.project.sunglassbungalow.exception.OrderNotFoundException;
import ca.project.sunglassbungalow.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static ca.project.sunglassbungalow.utils.constants.Constants.API_PREFIX;

/**
 * The type Orde controller.
 */
@RestController
@RequestMapping(API_PREFIX+"order")
public class OrdeController {

    @Autowired
    private OrderService orderService;




    /**
     * Find all response entity.
     *
     * @return the response entity
     */
    @GetMapping("all")
    public ResponseEntity<List<Order>> findAll()
    {
        return new ResponseEntity<>(orderService.findAll(), HttpStatus.OK);
    }

    /**
     * Find by id response entity.
     *
     * @param id the id
     * @return the response entity
     * @throws OrderNotFoundException the order not found exception
     */
    @GetMapping("find/{id}")
    public ResponseEntity<?> findById(@PathVariable Long id) throws OrderNotFoundException {
        if(id!=null && orderService.findById(id)!=null)
        {
            return new ResponseEntity<>(orderService.findById(id),HttpStatus.OK);
        }
        else
        {
            return response(HttpStatus.BAD_REQUEST,"this order ID does not Exist");
        }

    }

    /**
     * Update status response entity.
     *
     * @param status the status
     * @param id     the id
     * @return the response entity
     * @throws OrderNotFoundException the order not found exception
     */
    @PostMapping("update-status/{id}/{status}")
    public ResponseEntity<?> updateStatus(@PathVariable String status,
                                              @PathVariable Long id) throws OrderNotFoundException {
        if(id!=null && orderService.findById(id)!=null)
        {
            return new ResponseEntity<>(orderService.updateStatus(id,status),HttpStatus.OK);
        }
        else
        {
            return response(HttpStatus.BAD_REQUEST,"this order ID does not Exist");
        }

    }

    /**
     * Delete response entity.
     *
     * @param id the id
     * @return the response entity
     */
    @DeleteMapping("delete/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id) throws OrderNotFoundException {
        if(id!=null && orderService.findById(id)!=null)
        {
            orderService.delete(id);
            return new ResponseEntity<>(HttpStatus.OK);
        }
        else
        {
            return response(HttpStatus.BAD_REQUEST,"this order ID does not Exist");
        }

    }

    private ResponseEntity<HttpResponse> response(HttpStatus httpStatus, String message) {
        return new ResponseEntity<>(new HttpResponse(httpStatus.value(), httpStatus, httpStatus.getReasonPhrase().toUpperCase(),
                message), httpStatus);
    }
}
