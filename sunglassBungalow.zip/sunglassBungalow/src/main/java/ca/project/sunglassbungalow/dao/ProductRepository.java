package ca.project.sunglassbungalow.dao;

import ca.project.sunglassbungalow.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ProductRepository extends JpaRepository<Product, Long> {

    List<Product> findAllByNameContainingIgnoreCase(String name);
    List<Product> findAllByBrandContainingIgnoreCase(String brand);
    List<Product> findAllByCategory_Name(String categoryName);

    List<Product> findAllByColorIn(List<String> colors);
    List<Product> findAllByColor(String color);



}