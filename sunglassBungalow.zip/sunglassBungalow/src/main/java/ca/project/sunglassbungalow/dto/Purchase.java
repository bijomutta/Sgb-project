package ca.project.sunglassbungalow.dto;

import ca.project.sunglassbungalow.entity.Address;
import ca.project.sunglassbungalow.entity.Order;
import ca.project.sunglassbungalow.entity.OrderItem;
import ca.project.sunglassbungalow.entity.User;
import lombok.Data;

import java.util.Set;

@Data
public class Purchase {

    private User customer;
    private Address shippingAddress;
    private Address billingAddress;
    private Order order;
    private Set<OrderItem> orderItems;
}
