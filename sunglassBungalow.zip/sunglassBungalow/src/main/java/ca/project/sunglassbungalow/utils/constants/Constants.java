package ca.project.sunglassbungalow.utils.constants;

public class Constants {
    public static final String API_PREFIX="api/" ;


}
