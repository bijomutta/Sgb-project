package ca.project.sunglassbungalow.entity;

import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.sql.Blob;
import java.util.Base64;
import java.util.Date;
import java.util.List;


@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "product")
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "category_id",nullable = false)
    private ProductCategory category;

    @Column(name = "name")
    private String name;
    @Column(name = "description")
    private String description;

    @Column(name = "brand")
    private String brand;
    private BigDecimal oldPrice;
    private BigDecimal newPrice;
    private int discount;
    private int cartCount;
    private String[] color;

    @Column(name = "image_Url")
    @Lob
    private String image;
    @Column(name = "availibility_count")
    private int availibilityCount;
    private int ratingsCount;
    private int ratingsValue;
    @Column(name = "date_created")
    @CreationTimestamp
    private Date dateCreated;

    @Column(name = "last_updated")
    @UpdateTimestamp
    private Date lastUpdated;

    private Long[] reviewId;
//   @Transient
//    public String getBase64()
//   {

//       String base64String = Base64.getEncoder().encodeToString(image);
//       return "base64String";
//   }
}
