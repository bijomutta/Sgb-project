package ca.project.sunglassbungalow.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ProductDTO {

    @JsonProperty("name")
    private String name;
    @JsonProperty("description")
    private String description;
    @JsonProperty("oldPrice")
    private BigDecimal oldPrice;
    @JsonProperty("newPrice")
    private BigDecimal newPrice;
    @JsonProperty("discount")
    private int discount;
    @JsonProperty("availibilityCount")
    private int availibilityCount;
    @JsonProperty("brand")
    private String brand;
    @JsonProperty("color")
    private String[] color;
    @JsonProperty("image")
    private String image;
    @JsonProperty("categoryId")
    private long categoryId;
}
