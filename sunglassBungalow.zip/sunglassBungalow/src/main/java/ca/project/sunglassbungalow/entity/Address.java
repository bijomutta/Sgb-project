package ca.project.sunglassbungalow.entity;


import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;



@Entity
@Table(name="address")
@Getter
@Setter
public class Address {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private Long id;

    @Column(name="street")
    private String addressLine;

    @Column(name="city")
    private String city;

    @Column(name="place")
    private String place;

    @Column(name="country")
    private String country;

    @Column(name="zip_code")
    private String postalCode;








}
