package ca.project.sunglassbungalow.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import jakarta.persistence.*;
import net.minidev.json.annotate.JsonIgnore;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
@Table(name = "customer")
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "first_name")
    private String firstName;

    @Column(name = "last_name")
    private String lastName;

    @Column(name = "email")
    private String email;

    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private String password;

    @Column(name = "phone")
    private String phone;


    private String[] roles;

    private Date lastLoginDate;

    private Date lastLoginDateDisplay;


    private Boolean isAccountExpired;
    private Boolean isAccountNonLocked;
    private Boolean isEnabled;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "shipping_address_id", referencedColumnName = "id")
    private Address shippingAddress;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "billing_address_id", referencedColumnName = "id")
    private Address billingAddress;



//    @OneToMany(mappedBy = "customer", fetch = FetchType.EAGER)
//    private Set<Order> orders = new HashSet<>();


//    public void add(Order order) {
//        if (order != null) {
//            if (orders == null) {
//                orders = new HashSet<>();
//            }
//            orders.add(order);
//            order.setCustomer(this);
//        }
//    }
}

