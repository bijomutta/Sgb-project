package ca.project.sunglassbungalow.dao;


import ca.project.sunglassbungalow.entity.Review;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReviewRepository extends JpaRepository<Review,Long> {
}
