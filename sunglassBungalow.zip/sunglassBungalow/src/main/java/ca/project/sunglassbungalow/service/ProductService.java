package ca.project.sunglassbungalow.service;

import ca.project.sunglassbungalow.dto.ProductDTO;
import ca.project.sunglassbungalow.dto.ReviewDTO;
import ca.project.sunglassbungalow.entity.Product;
import ca.project.sunglassbungalow.entity.Review;
import ca.project.sunglassbungalow.exception.CategoryNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

/**
 * The interface Product service.
 */
@Service
public interface ProductService {
    /**
     * Sort by name list.
     *
     * @param name the name
     * @param dir  the dir
     * @return the list
     */
    List<Product> sortByName(String name, String dir);

    /**
     * Sort by price list.
     *
     * @param price the price
     * @param dir   the dir
     * @return the list
     */
    List<Product> sortByPrice(String price, String dir);

    /**
     * Filter by brand list.
     *
     * @param brand the brand
     * @return the list
     */
    List<Product> filterByBrand(String[] brands);

    /**
     * Filter by name list.
     *
     * @param name the name
     * @return the list
     */
    List<Product> filterByName(String name);

    List<Product> filterByColor(List<String> color);

    /**
     * Filter by category list.
     *
     * @param category the category
     * @return the list
     */
    List<Product> filterByCategory(String category);

    /**
     * Find all list.
     *
     * @return the list
     */
    List<Product> findAll();

    /**
     * Find by id product.
     *
     * @param productId the product id
     * @return the product
     */
    Product findById(Long productId);

    /**
     * Add product product.
     *
     * @param productDTO the product dto
     * @return the product
     */
    Product addProduct(ProductDTO productDTO) throws CategoryNotFoundException;

    /**
     * Update product product.
     *
     * @param productId  the product id
     * @param productDTO the product dto
     * @return the product
     */
    Product updateProduct(Long productId, ProductDTO productDTO);

    Product addReview(Long productId, ReviewDTO reviewDTO);

    List<Review> getReviews(Long id);

    /**
     * Delete product.
     *
     * @param productId the product id
     */
    void deleteProduct(Long productId);
}
