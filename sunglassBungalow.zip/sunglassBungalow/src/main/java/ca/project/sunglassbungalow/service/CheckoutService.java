package ca.project.sunglassbungalow.service;

import ca.project.sunglassbungalow.dto.Purchase;
import ca.project.sunglassbungalow.dto.PurchaseResponse;


public interface CheckoutService {
    /**
     * Place order purchase response.
     *
     * @param purchase the purchase
     * @return the purchase response
     */
    PurchaseResponse placeOrder(Purchase purchase) ;
}
