package ca.project.sunglassbungalow.controller;

import ca.project.sunglassbungalow.dto.CategoryDTO;
import ca.project.sunglassbungalow.entity.ProductCategory;
import ca.project.sunglassbungalow.exception.HttpResponse;
import ca.project.sunglassbungalow.service.ProductCategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import static ca.project.sunglassbungalow.utils.constants.Constants.API_PREFIX;

/**
 * The type Category controller.
 */
@RestController
@RequestMapping(API_PREFIX+"category")
public class CategoryController {

    @Autowired
    private ProductCategoryService categoryService;

    /**
     * Find all response entity.
     *
     * @return the response entity
     */
    @GetMapping("all")
    public ResponseEntity<List<ProductCategory>> findAll()
    {
        return new ResponseEntity<>(categoryService.findAll(), HttpStatus.OK);
    }

    /**
     * Create response entity.
     *
     * @param category the category
     * @return the response entity
     */
    @PostMapping("add")
    public ResponseEntity<ProductCategory> create(@RequestBody CategoryDTO category)
    {
        return new ResponseEntity<>(categoryService.addCategory(category),HttpStatus.OK);
    }

    /**
     * Update response entity.
     *
     * @param category the category
     * @param id       the id
     * @return the response entity
     */
    @PutMapping("update/{id}")
    public ResponseEntity<?> update(@RequestBody CategoryDTO category,
                                                  @PathVariable Long id)
    {

        if(id!=null && categoryService.findById(id)!=null)
        {
            return new ResponseEntity<>(categoryService.updateCategory(id,category),HttpStatus.OK);
        }
        else
        {
            return response(HttpStatus.BAD_REQUEST,"this Category ID does Not Exist");
        }
    }

    /**
     * Delete response entity.
     *
     * @param id the id
     * @return the response entity
     */
    @DeleteMapping("delete/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id)
    {
        if(id!=null && categoryService.findById(id)!=null)
        {
            categoryService.deleteCategory(id);
            return new ResponseEntity<>(HttpStatus.OK);
        }
        else
        {
            return response(HttpStatus.BAD_REQUEST,"this Category ID does Not Exist");
        }

    }

    private ResponseEntity<HttpResponse> response(HttpStatus httpStatus, String message) {
        return new ResponseEntity<>(new HttpResponse(httpStatus.value(), httpStatus, httpStatus.getReasonPhrase().toUpperCase(),
                message), httpStatus);
    }
}
