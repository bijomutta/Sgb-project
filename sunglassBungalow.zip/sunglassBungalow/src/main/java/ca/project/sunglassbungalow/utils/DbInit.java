package ca.project.sunglassbungalow.utils;

import ca.project.sunglassbungalow.dto.UserDTO;
import ca.project.sunglassbungalow.entity.User;
import ca.project.sunglassbungalow.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
@Service
public class DbInit implements CommandLineRunner {


    @Autowired
    private UserService userService;



    @Override
    public void run(String... args) throws Exception {

        List<User> users=new ArrayList<>();
         users.forEach(user -> {
             userService.delete(user.getId());
         });

        if(userService.findUserByEmail("admin@gmail.com" ) == null) {

            UserDTO userDTO=new UserDTO();
            userDTO.setEmail("admin@gmail.com");
            userDTO.setFirstName("admin");
            userDTO.setLastName("admin");
            userDTO.setPassword("12345678");

           userService.createUser(userDTO);
        }
        if(userService.findUserByEmail("user@gmail.com" ) == null) {

            UserDTO userDTO=new UserDTO();
            userDTO.setEmail("user@gmail.com");
            userDTO.setFirstName("customer");
            userDTO.setLastName("customer");
            userDTO.setPassword("12345678");

            userService.register(userDTO);
        }


    }
}
