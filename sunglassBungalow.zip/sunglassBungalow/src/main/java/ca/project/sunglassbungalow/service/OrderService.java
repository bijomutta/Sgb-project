package ca.project.sunglassbungalow.service;

import ca.project.sunglassbungalow.entity.Order;
import ca.project.sunglassbungalow.exception.OrderNotFoundException;

import java.util.List;

/**
 * The interface Order service.
 */
public interface OrderService {
    List<Order> findByCustomerEmail(String email);

    /**
     * Find all list.
     *
     * @return the list
     */
    List<Order> findAll();

    /**
     * Update status order.
     *
     * @param orderId the order id
     * @param status  the status
     * @return the order
     * @throws OrderNotFoundException the order not found exception
     */
    Order updateStatus(Long orderId, String status) throws OrderNotFoundException;

    /**
     * Find by id order.
     *
     * @param orderId the order id
     * @return the order
     * @throws OrderNotFoundException the order not found exception
     */
    Order findById(Long orderId) throws OrderNotFoundException;

    /**
     * Delete.
     *
     * @param orderid the orderid
     */
    void delete(Long orderid);
}
