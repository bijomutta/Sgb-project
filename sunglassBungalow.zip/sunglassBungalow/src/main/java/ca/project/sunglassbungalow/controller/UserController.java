package ca.project.sunglassbungalow.controller;

import ca.project.sunglassbungalow.dto.UserDTO;
import ca.project.sunglassbungalow.entity.User;
import ca.project.sunglassbungalow.exception.*;
import ca.project.sunglassbungalow.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static ca.project.sunglassbungalow.utils.constants.Constants.API_PREFIX;
import static ca.project.sunglassbungalow.utils.constants.SecurityConstant.JWT_TOKEN_HEADER;
import static org.springframework.http.HttpStatus.OK;

/**
 * The type User controller.
 */
@RestController
@RequestMapping(API_PREFIX+"user")
public class UserController {

    @Autowired
    private UserService userService;

    public static final String USER_DELETED_SUCCESSFULLY = "User deleted successfully";

    /**
     * Find all response entity.
     *
     * @return the response entity
     */
    @GetMapping("all/customer")
    public ResponseEntity<List<User>> findAllCustomers()
    {
        return new ResponseEntity<>(userService.findAllCustomer(), OK);
    }

    @GetMapping("all/admin")
    public ResponseEntity<List<User>> findAllAdmins()
    {
        return new ResponseEntity<>(userService.findAllAdmins(), OK);
    }

    /**
     * Find by id response entity.
     *
     * @param id the id
     * @return the response entity
     */
    @GetMapping("find/{id}")
    public ResponseEntity<?> findById(@PathVariable Long id) throws UserNotFoundException {


        if(id!=null && userService.findById(id)!=null)
        {
            return new ResponseEntity<>(userService.findById(id), OK);
        }
        else
        {
            return response(HttpStatus.BAD_REQUEST,"this user ID Does not exist");
        }
    }

    /**
     * Create response entity.
     *
     * @param userDTO the user dto
     * @return the response entity
     */
    @PostMapping("customer")
    public ResponseEntity<User> createCustomer(@RequestBody UserDTO userDTO) throws EmailExistException, UserNotFoundException {
        return new ResponseEntity<>(userService.register(userDTO), OK);
    }
    @PostMapping("admin")
    public ResponseEntity<User> createAdmin(@RequestBody UserDTO userDTO) throws EmailExistException, UserNotFoundException {
        return new ResponseEntity<>(userService.createUser(userDTO), OK);
    }


    /**
     * Update response entity.
     *
     * @param userDTO the user dto
     * @param id      the id
     * @return the response entity
     */
    @PutMapping("update/{id}")
    public ResponseEntity<?> update(@RequestBody UserDTO userDTO,
                                       @PathVariable Long id) throws EmailNotFoundException, UserNotFoundException {

        if(id!=null && userService.findById(id)!=null)
        {
            return new ResponseEntity<>(userService.updateUser(id,userDTO), OK);
        }
        else
        {
            return response(HttpStatus.BAD_REQUEST,"this user ID Does not exist");
        }
    }

    /**c
     * Delete response entity.
     *
     * @param id the id
     * @return the response entity
     */
    @DeleteMapping("delete/{id}")
    public ResponseEntity<HttpResponse> delete(@PathVariable Long id) throws UserNotFoundException {
        if(id!=null && userService.findById(id)!=null)
        {
            userService.delete(id);
            return response(OK,USER_DELETED_SUCCESSFULLY);
        }
        else
        {
            return response(HttpStatus.BAD_REQUEST,"this user ID Does not exist");
        }

    }


    private ResponseEntity<HttpResponse> response(HttpStatus httpStatus, String message) {
        return new ResponseEntity<>(new HttpResponse(httpStatus.value(), httpStatus, httpStatus.getReasonPhrase().toUpperCase(),
                message), httpStatus);
    }
}
