package ca.project.sunglassbungalow.controller;

import ca.project.sunglassbungalow.dto.Purchase;
import ca.project.sunglassbungalow.dto.PurchaseResponse;
import ca.project.sunglassbungalow.service.CheckoutService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static ca.project.sunglassbungalow.utils.constants.Constants.API_PREFIX;

@RestController
@RequestMapping(API_PREFIX+"checkout")
public class CheckoutController {

    @Autowired
    private CheckoutService checkoutService;

    @PostMapping("/purchase")
    public PurchaseResponse placeOrder(@RequestBody Purchase purchase)  {
        PurchaseResponse purchaseResponse=checkoutService.placeOrder(purchase);
        return purchaseResponse;
    }
}
