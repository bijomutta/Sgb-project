package ca.project.sunglassbungalow.exception;

public class IdNotFoundException extends Exception{
    public IdNotFoundException(String message) {
        super(message);
    }
}
