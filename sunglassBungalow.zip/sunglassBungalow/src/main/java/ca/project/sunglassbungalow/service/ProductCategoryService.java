package ca.project.sunglassbungalow.service;

import ca.project.sunglassbungalow.dto.CategoryDTO;
import ca.project.sunglassbungalow.entity.ProductCategory;
import org.springframework.stereotype.Service;

import java.util.List;


/**
 * The interface Product category service.
 */
public interface ProductCategoryService {
    /**
     * Find by id product category.
     *
     * @param categoryId the category id
     * @return the product category
     */
    ProductCategory findById(Long categoryId);

    /**
     * Find all list.
     *
     * @return the list
     */
    List<ProductCategory> findAll();

    /**
     * Add category product category.
     *
     * @param categoryDTO the category dto
     * @return the product category
     */
    ProductCategory addCategory(CategoryDTO categoryDTO);

    /**
     * Update category product category.
     *
     * @param categoryId  the category id
     * @param categoryDTO the category dto
     * @return the product category
     */
    ProductCategory updateCategory(Long categoryId, CategoryDTO categoryDTO);

    /**
     * Delete category.
     *
     * @param categoryId the category id
     */
    void deleteCategory(Long categoryId);
}
