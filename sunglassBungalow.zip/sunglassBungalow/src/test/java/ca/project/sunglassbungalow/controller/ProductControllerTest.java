package ca.project.sunglassbungalow.controller;

import ca.project.sunglassbungalow.dto.ProductDTO;
import ca.project.sunglassbungalow.dto.UserDTO;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletResponse;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.io.File;
import java.io.UnsupportedEncodingException;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc(addFilters = false)
class ProductControllerTest {

    @Value("classpath:test/product.json")
    private Resource resource;

    @Autowired
    private MockMvc mockMvc;

    @Test
    void sortByName() throws Exception {
        ResultActions expect= mockMvc.perform( MockMvcRequestBuilders
                        .get("/api/product/sort-name")
                        .accept(MediaType.APPLICATION_JSON)
                        .param("name","name")
                        .param("dir","asc"))
                .andExpect(status().isOk());


        System.out.println(expect.andReturn().getResponse().getContentAsString());
        assertTrue(expect.andReturn().getResponse().getStatus()== HttpServletResponse.SC_OK);

    }

    @Test
    void sortByPrice() throws Exception {
        ResultActions expect= mockMvc.perform( MockMvcRequestBuilders
                        .get("/api/product/sort-price")
                        .accept(MediaType.APPLICATION_JSON)
                        .param("name","price")
                        .param("dir","asc"))
                .andExpect(status().isOk());


        System.out.println(expect.andReturn().getResponse().getContentAsString());
        assertTrue(expect.andReturn().getResponse().getStatus()== HttpServletResponse.SC_OK);

    }

    @Test
    void filterByName() throws Exception {
        ResultActions expect= mockMvc.perform( MockMvcRequestBuilders
                        .get("/api/product/filter-name")
                        .accept(MediaType.APPLICATION_JSON)
                        .param("name","summer Glasses"))
                .andExpect(status().isOk());


        System.out.println(expect.andReturn().getResponse().getContentAsString());
        assertTrue(expect.andReturn().getResponse().getStatus()== HttpServletResponse.SC_OK);

    }

    @Test
    void filterByBrand() throws Exception {
        ResultActions expect= mockMvc.perform( MockMvcRequestBuilders
                        .get("/api/product/filter-brand")
                        .accept(MediaType.APPLICATION_JSON)
                        .param("name","dior"))
                .andExpect(status().isOk());


        System.out.println(expect.andReturn().getResponse().getContentAsString());
        assertTrue(expect.andReturn().getResponse().getStatus()== HttpServletResponse.SC_OK);

    }

    @Test
    void filterByCategory() throws Exception {
        ResultActions expect= mockMvc.perform( MockMvcRequestBuilders
                        .get("/api/product/filter-category")
                        .accept(MediaType.APPLICATION_JSON)
                        .param("name","men"))
                .andExpect(status().isOk());


        System.out.println(expect.andReturn().getResponse().getContentAsString());
        assertTrue(expect.andReturn().getResponse().getStatus()== HttpServletResponse.SC_OK);

    }

    @Test
    void findAll() throws Exception {
        ResultActions expect= mockMvc.perform( MockMvcRequestBuilders
                        .get("/api/product/all")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());


        System.out.println(expect.andReturn().getResponse().getContentAsString());
        assertTrue(expect.andReturn().getResponse().getStatus()== HttpServletResponse.SC_OK);

    }

    @Test
    void create() throws Exception {

        ObjectMapper mapper=new ObjectMapper();
        ProductDTO productDTO=mapper.readValue(new File(resource.getFile().getPath()), ProductDTO.class);
        String jsonBody= mapper.writeValueAsString(productDTO);
        ResultActions resultActions=mockMvc.perform(MockMvcRequestBuilders
                        .post("/api/product/add")
                        .accept(MediaType.APPLICATION_JSON)
                        .content(jsonBody)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
        System.out.println(resultActions.andReturn().getResponse().getContentAsString());
    }
}