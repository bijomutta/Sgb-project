package ca.project.sunglassbungalow.controller;

import ca.project.sunglassbungalow.dto.UserDTO;
import ca.project.sunglassbungalow.entity.User;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.servlet.http.HttpServletResponse;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureWebMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.io.File;
import java.io.IOException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc(addFilters = false)
class UserControllerTest {


    @Value("classpath:test/user.json")
    private Resource resource;

    @Autowired
    private MockMvc mockMvc;

    @Test
    void findAll() throws Exception {

      ResultActions expect= mockMvc.perform( MockMvcRequestBuilders
                        .get("/api/user/all/customer")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());


      System.out.println(expect.andReturn().getResponse().getContentAsString());
      assertTrue(expect.andReturn().getResponse().getStatus()== HttpServletResponse.SC_OK);

        ResultActions expect2= mockMvc.perform( MockMvcRequestBuilders
                        .get("/api/user/all/admin")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());


        System.out.println(expect2.andReturn().getResponse().getContentAsString());
        assertTrue(expect2.andReturn().getResponse().getStatus()== HttpServletResponse.SC_OK);

    }

    @Test
    void findById() throws Exception {


    }


    @Test
    void create() throws Exception {
        ObjectMapper mapper=new ObjectMapper();
        UserDTO user=mapper.readValue(new File(resource.getFile().getPath()), UserDTO.class);
        String jsonBody= mapper.writeValueAsString(user);
        ResultActions resultActions=mockMvc.perform(MockMvcRequestBuilders
                .post("/api/user/customer")
                .accept(MediaType.APPLICATION_JSON)
                .content(jsonBody)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
        System.out.println(resultActions.andReturn().getResponse().getContentAsString());
    }

    @Test
    void update() {
    }

    @Test
    void delete() {
    }
}