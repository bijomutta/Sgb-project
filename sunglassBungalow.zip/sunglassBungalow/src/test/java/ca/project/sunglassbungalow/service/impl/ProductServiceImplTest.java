package ca.project.sunglassbungalow.service.impl;

import ca.project.sunglassbungalow.dto.CategoryDTO;
import ca.project.sunglassbungalow.dto.ProductDTO;
import ca.project.sunglassbungalow.entity.Product;
import ca.project.sunglassbungalow.entity.ProductCategory;
import ca.project.sunglassbungalow.exception.CategoryNotFoundException;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class ProductServiceImplTest {

    @Autowired
    private ProductServiceImpl productService;

    @Autowired
    private ProductCategoryServiceImpl productCategoryService;

    @Test
    void sortByName() throws IOException, CategoryNotFoundException {
        this.addProduct();
        List<Product> products=productService.sortByName("name","desc");
        assertNotNull(products);

    }

    @Test
    void sortByPrice() throws IOException, CategoryNotFoundException {
        this.addProduct();
        List<Product> products=productService.sortByPrice("price","desc");
        assertNotNull(products);

    }

//    @Test
//    void filterByBrand() throws IOException, CategoryNotFoundException {
//        this.addProduct();
//        List<Product> products=productService.filterByBrand("dior");
//        assertNotNull(products);
//
//    }

    @Test
    void filterByName() throws IOException, CategoryNotFoundException {
        this.addProduct();
        List<Product> products=productService.filterByName("summer Glasses");
        assertNotNull(products);

    }

    @Test
    void filterByCategory() throws IOException, CategoryNotFoundException {
        this.addProduct();
        List<Product> products=productService.filterByCategory("men");
        assertNotNull(products);


    }

    @Test
    void findAll() throws IOException, CategoryNotFoundException {
        this.addProduct();
        List<Product> products=productService.findAll();
        assertNotNull(products);
        System.out.println(products);

    }

    @Test
    void findById() {
        List<Product> products=productService.findAll();
        Product product=productService.findById(products.get(0).getId());
        assertNotNull(product);

    }

    @Test
    void addProduct() throws IOException, CategoryNotFoundException {
        //create cateogory first
        CategoryDTO categoryDTO=CategoryDTO.builder()
                .name("men")
                .description("for men only")
                .build();
        ProductCategory productCategory=productCategoryService.addCategory(categoryDTO);
        assertNotNull(productCategory);
        assertEquals(productCategory.getName(),categoryDTO.getName());

        //then create the product
        ProductDTO productDTO= ProductDTO.builder()
                .name("summer Glasses")
                .brand("dior")
                .availibilityCount(50)
//                .colour("red")
//                .price(BigDecimal.valueOf(100))
                .description("new glasses")
                .categoryId(productCategory.getId())
                .build();

        Product product=productService.addProduct(productDTO);
        assertNotNull(product);
        assertEquals(productDTO.getBrand(),product.getBrand());


    }

    @Test
    void updateProduct() throws IOException, CategoryNotFoundException {

        //create cateogory first
        CategoryDTO categoryDTO=CategoryDTO.builder()
                .name("women")
                .description("test test")
                .build();
        ProductCategory productCategory=productCategoryService.addCategory(categoryDTO);
        assertNotNull(productCategory);
        assertEquals(productCategory.getName(),categoryDTO.getName());

        ProductDTO productDTO= ProductDTO.builder()
                .name("summer Glasses")
                .brand("dior")
                .availibilityCount(50)
//                .colour("red")
//                .price(BigDecimal.valueOf(100))
                .description("new glasses")
                .categoryId(productCategory.getId())
                .build();

        Product product=productService.addProduct(productDTO);
        assertNotNull(product);
        assertEquals(productDTO.getBrand(),product.getBrand());

    }

    @Test
    void deleteProduct() {
        List<Product> productList=productService.findAll();

        productList.forEach(prod->{
            productService.deleteProduct(prod.getId());
            System.out.println(prod.getName() +" Deleted");
        });


    }
}