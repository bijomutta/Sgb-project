package ca.project.sunglassbungalow.controller;

import ca.project.sunglassbungalow.dto.CategoryDTO;
import ca.project.sunglassbungalow.dto.ProductDTO;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletResponse;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.io.File;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc(addFilters = false)
class CategoryControllerTest {

    @Value("classpath:test/category.json")
    private Resource resource;

    @Autowired
    private MockMvc mockMvc;

    @Test
    void findAll() throws Exception {
        ResultActions expect= mockMvc.perform( MockMvcRequestBuilders
                        .get("/api/category/all")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());


        System.out.println(expect.andReturn().getResponse().getContentAsString());
        assertTrue(expect.andReturn().getResponse().getStatus()== HttpServletResponse.SC_OK);

    }

    @Test
    void create() throws Exception {
        ObjectMapper mapper=new ObjectMapper();
        CategoryDTO categoryDTO=mapper.readValue(new File(resource.getFile().getPath()), CategoryDTO.class);
        String jsonBody= mapper.writeValueAsString(categoryDTO);
        ResultActions resultActions=mockMvc.perform(MockMvcRequestBuilders
                        .post("/api/category/add")
                        .accept(MediaType.APPLICATION_JSON)
                        .content(jsonBody)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
        System.out.println(resultActions.andReturn().getResponse().getContentAsString());
    }
}