package ca.project.sunglassbungalow.service.impl;

import ca.project.sunglassbungalow.dto.CategoryDTO;
import ca.project.sunglassbungalow.entity.Product;
import ca.project.sunglassbungalow.entity.ProductCategory;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class ProductCategoryServiceImplTest {

    @Autowired
    private ProductCategoryServiceImpl productCategoryService;


    @Test
    void addCategory() {
        CategoryDTO categoryDTO=CategoryDTO.builder()
                .name("men")
                .description("for men only")
                .build();
        ProductCategory productCategory=productCategoryService.addCategory(categoryDTO);
        assertNotNull(productCategory);
        assertEquals(productCategory.getName(),categoryDTO.getName());


    }

    @Test
    void updateCategory() {

        //create the new category
        CategoryDTO categoryDTO=CategoryDTO.builder()
                .name("men")
                .description("for men only")
                .build();
        ProductCategory productCategory=productCategoryService.addCategory(categoryDTO);
        assertNotNull(productCategory);
        assertEquals(productCategory.getName(),categoryDTO.getName());

        // then update
        CategoryDTO categoryDTO2=CategoryDTO.builder()
                .name("women")
                .description("women only")
                .build();
        ProductCategory productCategory2=productCategoryService.updateCategory(productCategory.getId(),categoryDTO);
        assertNotNull(productCategory);
        assertEquals(productCategory.getName(),categoryDTO.getName());

        System.out.println(productCategory);
    }

    @Test
    void findAll()
    {
        List<ProductCategory> productCategories=productCategoryService.findAll();
        assertNotNull(productCategories);
        assertTrue(productCategories.size()>0);

    }

    @Test
    void deleteCategory() {
        List<ProductCategory> productCategories=productCategoryService.findAll();
        //create the new category
        CategoryDTO categoryDTO=CategoryDTO.builder()
                .name("men")
                .description("for men only")
                .build();
        ProductCategory productCategory=productCategoryService.addCategory(categoryDTO);

        productCategoryService.deleteCategory(productCategory.getId());

    }
}