package ca.project.sunglassbungalow.controller;

import ca.project.sunglassbungalow.dto.ProductDTO;
import ca.project.sunglassbungalow.dto.Purchase;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.io.File;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc(addFilters = false)
class CheckoutControllerTest {

    @Value("classpath:test/purchase.json")
    private Resource resource;

    @Autowired
    private MockMvc mockMvc;

    @Test
    void placeOrder() throws Exception {

        ObjectMapper mapper=new ObjectMapper();
        Purchase purchase=mapper.readValue(new File(resource.getFile().getPath()), Purchase.class);
        String jsonBody= mapper.writeValueAsString(purchase);
        ResultActions resultActions=mockMvc.perform(MockMvcRequestBuilders
                        .post("/api/checkout/purchase")
                        .accept(MediaType.APPLICATION_JSON)
                        .content(jsonBody)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
        System.out.println(resultActions.andReturn().getResponse().getContentAsString());
    }

}