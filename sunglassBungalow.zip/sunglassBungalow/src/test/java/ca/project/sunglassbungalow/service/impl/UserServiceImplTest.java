package ca.project.sunglassbungalow.service.impl;

import ca.project.sunglassbungalow.dto.UserDTO;
import ca.project.sunglassbungalow.entity.User;
import ca.project.sunglassbungalow.exception.EmailExistException;
import ca.project.sunglassbungalow.exception.EmailNotFoundException;
import ca.project.sunglassbungalow.exception.UserNotFoundException;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;
import java.util.Random;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class UserServiceImplTest {

    @Autowired
    private UserServiceImpl userService;

    @Test
    void findById() throws EmailExistException, UserNotFoundException {
        this.createUser();
        List<User> users=userService.findAllAdmins();
        users.forEach(user -> {
            assertNotNull(user);
            try {
                assertEquals(user.getEmail(),userService.findById(user.getId()).getEmail());
            } catch (UserNotFoundException e) {
                throw new RuntimeException(e);
            }
        });
    }

    @Test
    void createUser() throws EmailExistException, UserNotFoundException {

        String prefix= UUID.randomUUID().toString();
        UserDTO userDTO=UserDTO.builder()
                .email(prefix+"@gmail.com")
                .firstName("haroun")
                .lastName("haroun")
                .password("12345678")
                .build();
        User user=userService.createUser(userDTO);
        assertNotNull(user);
        assertEquals(user.getEmail(),userDTO.getEmail());


    }

    @Test
    void updateUser() throws EmailNotFoundException, EmailExistException, UserNotFoundException {
        //create user
        String prefix= UUID.randomUUID().toString();
        UserDTO userDTO=UserDTO.builder()
                .email(prefix+"@gmail.com")
                .firstName("haroun")
                .lastName("haroun")
                .password("12345678")
                .build();
        User user=userService.createUser(userDTO);
        assertNotNull(user);


        //then update the user
        UserDTO userDTO2=UserDTO.builder()
                .email(user.getEmail())
                .firstName("ali")
                .lastName("mark")
                .password("12345678")
                .build();
        User userUpdated=userService.updateUser(user.getId(),userDTO2);
        assertNotNull(user);

    }

    @Test
    void deleteUser()
    {
        List<User>  users=userService.findAllAdmins();
        assertNotNull(users);
        users.forEach(user->{
            userService.delete(user.getId());
            System.out.println("User Deleted");
        });
    }
}