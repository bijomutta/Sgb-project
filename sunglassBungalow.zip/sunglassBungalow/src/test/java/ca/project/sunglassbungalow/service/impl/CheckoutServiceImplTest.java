package ca.project.sunglassbungalow.service.impl;

import ca.project.sunglassbungalow.dto.Purchase;
import ca.project.sunglassbungalow.dto.PurchaseResponse;
import ca.project.sunglassbungalow.entity.Address;
import ca.project.sunglassbungalow.entity.Order;
import ca.project.sunglassbungalow.entity.OrderItem;
import ca.project.sunglassbungalow.entity.Product;
import ca.project.sunglassbungalow.exception.CategoryNotFoundException;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class CheckoutServiceImplTest  {

    @Autowired
    private CheckoutServiceImpl checkoutService;
    @Autowired
    private ProductServiceImpl productService;

    @Autowired
    private UserServiceImpl userService;

    @Test
    void placeOrder() throws CategoryNotFoundException, IOException {

        List<Product> products=productService.findAll();
        Product product=productService.findById(products.get(0).getId());
        assertNotNull(product);

        //creating a new purchase DTO
        Purchase purchase=new Purchase();

        //creating a new order model
        Order order=new Order();

        //creating a new address model
        Address address=new Address();
        address.setAddressLine("canada street 21");
        address.setPlace("toronto");
        address.setCity("toronto");
        address.setCountry("canada");
        address.setPostalCode("9000");

        //cearing order Items List
        Set<OrderItem> orderItemSet=new HashSet<>();
         BigDecimal totalPrice= BigDecimal.valueOf(0);
         for(int i=0;i<4 ;i++)
         {
             OrderItem orderItem=new OrderItem();
             orderItem.setProductId(products.get(i).getId());
             orderItem.setName(products.get(i).getName());
             orderItem.setQuantity(2);
             orderItem.setUnitPrice(products.get(i).getPrice());
             orderItem.setImage(null);
             orderItem.setOrder(order);
             totalPrice=totalPrice.add(products.get(i).getPrice());
             orderItemSet.add(orderItem);
         }

         order.setStatus("pending");
         order.setTotalPrice(totalPrice);
         order.setTotalQuantity(orderItemSet.size());


         //adding the order Items to the purchase DTO
        purchase.setOrderItems(orderItemSet);
        // using the same address for billing and shipping
        //adding the addresses to the purchase DTO
        purchase.setBillingAddress(address);
        purchase.setShippingAddress(address);
        //adding the order to the purchase DTO
        purchase.setOrder(order);
        //adding the customer to the purchase DTO
        purchase.setCustomer(userService.findAllCustomer().get(0));

        //calling the placeOrder Method from Service class
        PurchaseResponse response=checkoutService.placeOrder(purchase);

        assertNotNull(response);
        System.out.println(response.getOrderTrackingNumber());




    }
}