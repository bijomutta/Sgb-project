package ca.project.sunglassbungalow.service.impl;

import ca.project.sunglassbungalow.entity.Order;
import ca.project.sunglassbungalow.exception.OrderNotFoundException;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class OrderServiceImplTest {

    @Autowired
    private OrderServiceImpl orderService;

    @Test
    void findAll() {

        List<Order> orders=orderService.findAll();
        assertNotNull(orders);
    }

    @Test
    void updateStatus() throws OrderNotFoundException {

        List<Order> orders=orderService.findAll();
        assertNotNull(orders);

        if(!orders.isEmpty())
        {

          Order order=  orderService.updateStatus(orders.get(0).getId(),"delivered");
            assertEquals(order.getStatus(),"delivered");
        }

    }

    @Test
    void findById() throws OrderNotFoundException {
        List<Order> orders=orderService.findAll();
        assertNotNull(orders);

        if(!orders.isEmpty())
        {
            Order order=orderService.findById(orders.get(0).getId());
            assertNotNull(order);
        }

    }

    @Test
    void delete() {
        List<Order> orders=orderService.findAll();
        assertNotNull(orders);

        if(!orders.isEmpty())
        {
            orderService.delete(orders.get(0).getId());
        }
    }
}